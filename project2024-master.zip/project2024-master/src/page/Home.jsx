import React,{useState} from 'react';
import Header from "../component/Header/Header";

const Home = () => {
    return (
        <>
            <Header/>
        </>
    );
}

export default Home;