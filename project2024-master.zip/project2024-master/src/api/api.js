import axios from 'axios';

const api = axios.create();

export default api;